# Arcane Book — Forge 1.21.11

Prototype mod source project for Minecraft Java Edition / Forge 1.21.11.

Features currently implemented in source:
- Arcane Spellbook item in the Tools & Utilities creative tab.
- C key opens the spellbook screen; key is configurable in Controls.
- Three selectable spell examples and a study progress bar.
- Client-side particle demonstrations when casting a learned spell.

## Build
Requires Java 21 and network access for Gradle/Forge dependencies.
Run `./gradlew build` (Windows: `gradlew.bat build`). The jar is created in `build/libs/`.

A GitHub Actions workflow is included at `.github/workflows/build.yml`; push this project to a GitHub repository and use Actions to build it, then download the artifact named `ArcaneBookForge-jar`.

## Prototype limitations
This project has not yet been compiled or runtime-tested in this environment because Gradle's distribution cannot be downloaded here. The study state resets when the screen closes, learning currently advances by clicking Study rather than elapsed time, and spell effects are client-side visual demonstrations rather than authoritative multiplayer effects. These are prototype limitations, not finished gameplay.
