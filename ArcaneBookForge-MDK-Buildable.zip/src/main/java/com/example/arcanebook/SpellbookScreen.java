package com.example.arcanebook;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.client.gui.components.Button;
import net.minecraft.ChatFormatting;

public class SpellbookScreen extends Screen {
    private int studyTicks = 0;
    private int selectedSpell = 0;
    private boolean learned = false;
    private static final int STUDY_REQUIRED = 200; // 10 seconds at 20 TPS

    private final String[] spells = {"Spark", "Healing Light", "Frost Pulse"};

    public SpellbookScreen() {
        super(Component.literal("Arcane Spellbook"));
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int top = this.height / 2 - 70;
        for (int i = 0; i < spells.length; i++) {
            final int index = i;
            addRenderableWidget(Button.builder(Component.literal(spells[i]), b -> {
                selectedSpell = index;
                studyTicks = 0;
                learned = false;
            }).bounds(cx - 115, top + i * 25, 105, 20).build());
        }
        addRenderableWidget(Button.builder(Component.literal("Study"), b -> {
            if (!learned) studyTicks = Math.min(STUDY_REQUIRED, studyTicks + 20);
            if (studyTicks >= STUDY_REQUIRED) learned = true;
        }).bounds(cx + 5, top, 100, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Cast spell"), b -> castSelectedSpell())
                .bounds(cx + 5, top + 30, 100, 20).build());
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose())
                .bounds(cx - 40, top + 100, 80, 20).build());
    }

    @Override
    public void tick() {
        super.tick();
        // Holding the Study button is not required; each click advances one second.
    }

    private void castSelectedSpell() {
        if (!learned || minecraft == null || minecraft.player == null) return;
        switch (selectedSpell) {
            case 0 -> {
                minecraft.player.displayClientMessage(Component.literal("✦ A spark crackles from your spellbook!").withStyle(ChatFormatting.AQUA), true);
                minecraft.particleEngine.createTrackingEmitter(minecraft.player, net.minecraft.core.particles.ParticleTypes.ELECTRIC_SPARK, 20);
            }
            case 1 -> {
                minecraft.player.displayClientMessage(Component.literal("✧ Healing light surrounds you!").withStyle(ChatFormatting.GREEN), true);
                minecraft.particleEngine.createTrackingEmitter(minecraft.player, net.minecraft.core.particles.ParticleTypes.HAPPY_VILLAGER, 25);
            }
            case 2 -> {
                minecraft.player.displayClientMessage(Component.literal("❄ Frost energy swirls around you!").withStyle(ChatFormatting.BLUE), true);
                minecraft.particleEngine.createTrackingEmitter(minecraft.player, net.minecraft.core.particles.ParticleTypes.SNOWFLAKE, 25);
            }
        }
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        renderBackground(g, mouseX, mouseY, partialTick);
        int cx = width / 2;
        int top = height / 2 - 70;
        g.fill(cx - 130, top - 22, cx + 125, top + 132, 0xE922172F);
        g.drawCenteredString(font, "ARCANE BOOK", cx, top - 14, 0xFFD88CFF);
        g.drawString(font, "Choose a spell", cx - 115, top + 82, 0xFFFFFFFF);
        g.drawString(font, learned ? "Learned!" : "Learning: " + (studyTicks * 100 / STUDY_REQUIRED) + "%", cx + 5, top + 58, 0xFFFFFFFF);
        int barX = cx + 5, barY = top + 73, barW = 100;
        g.fill(barX, barY, barX + barW, barY + 8, 0xFF40364D);
        g.fill(barX, barY, barX + barW * studyTicks / STUDY_REQUIRED, barY + 8, 0xFFB95CFF);
        g.drawString(font, "Study clicks add 10%", cx + 5, top + 86, 0xFFBEB2C9);
        super.render(g, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
