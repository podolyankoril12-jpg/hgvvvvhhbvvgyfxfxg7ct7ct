package com.example.arcanebook;

import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.InputEvent;
import net.minecraftforge.eventbus.api.listener.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = ArcaneBookMod.MODID, value = Dist.CLIENT)
public final class ClientHooks {
    private ClientHooks() {}

    @SubscribeEvent
    public static void onKeyInput(InputEvent.Key event) {
        if (ClientModBusHooks.OPEN_BOOK == null || Minecraft.getInstance().screen != null) return;
        while (ClientModBusHooks.OPEN_BOOK.consumeClick()) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player != null) mc.setScreen(new SpellbookScreen());
        }
    }
}
